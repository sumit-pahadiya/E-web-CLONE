let ClockSlogan = () => {
  return (
    <p className="lead">
      This is the clock that shows the time in Bharat at all times.
    </p>
  );
};

export default ClockSlogan;
